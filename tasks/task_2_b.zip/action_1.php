<?
include $_SERVER["DOCUMENT_ROOT"].'/bitrix/modules/main/include/prolog_before.php';

/**
 * @return array
 */
function doAction()
{
    if (isset($_REQUEST['action']))
    {
        switch (filter_var($_REQUEST['action'], FILTER_SANITIZE_STRING, FILTER_FLAG_ENCODE_LOW))
        {
            case 'like':
                return likeItem();
                break;
        };
    };
    return array('error' => true, 'message' => 'Неверный запрос.' . var_export($_POST, true));
}


/**
 * добавление пользователя к элементу инфоблока ("мне нравится статья")
 * @return array
 */
function likeItem($iblock_id = 10)
{
    $result = array('error' => true, 'message' => 'не найден элемент');

    GLOBAL $USER;
    CModule::IncludeModule("Iblock");

    foreach ($_GET as $key => $value)
    {
        if (substr(filter_var($key, FILTER_SANITIZE_STRING,  FILTER_FLAG_ENCODE_LOW), 0, 8) === 'item_id_')
        {
            //выбирает значение свойства USERS_LIKES
            $res = CIBlockElement::GetProperty(
                $iblock_id,
                filter_var($key, FILTER_SANITIZE_NUMBER_INT),
                array(),
                array("CODE" => "USERS_LIKES"));
            while ($ob = $res->GetNext())
            {
                $users[] = $ob["VALUE"];
            }

            //удаляет пользователя из массива, если он там есть и добавляет, если его там нет.
            if(in_array($USER->GetID(), $users))
            {
                unset($users[array_search($USER->GetID(), $users)]);
                $message = "Мне нравится статья";
            }
            else
            {
                $users[] = $USER->GetID();
                $message = "Больше не нравится";
                $item_class = "don_t_like_more";
            }

            //обновляет свойство инфоблока
            CIBlockElement::SetPropertyValues(
                filter_var($key, FILTER_SANITIZE_NUMBER_INT),
                $iblock_id,
                $users,
                "USERS_LIKES"
            );

            $result = array('error' => false, 'message' => $message, 'item_class' => $item_class);
        }
    };
    return $result;
}



/**
 * ответ json ом
 * @param $output_data
 */
function response_json($output_data)
{
    ob_end_clean();
    header('Content-type: application/json; charset=utf-8');
    echo json_encode($output_data);
    die();
}

response_json((($output_data = doAction()) !== false) ? $output_data : array('error' => true, 'message' => 'Ошибка обрабортки запроса. Если ошибка повторяется, обратитесь в службу поддержки.'));

require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');
?>