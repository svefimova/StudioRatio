$(document).ready(function() {
    $(".like_but").on("click", function(){
        send_like($(this).attr("id"));
    })
})

function send_like(item_id){
    var url = '/ajax/action_1.php?action=like&' + item_id;

    $.ajax({
        type: 'POST',
        url: url,
        success: function (data)
        {
            if(data.item_class)
            {
                $("#"+item_id).addClass(data.item_class);
            }
            else
            {
                $("#"+item_id).removeClass("don_t_like_more");
            }
            $("#"+item_id).text(data.message);
        },
        error: function (data)
        {
            alert(data.message);
        }
    });
}