//3 как образец, счет от 0
var rating = 3;
var my_voice = rating;

$(function(){

    orange_stars(rating);

    $('.control_stars_star').on("mouseover", function(){
        var this_elem = $(this).index();
        my_voice = this_elem;
        orange_stars(this_elem);
    })

    $('.control_button').on("click", function(){
        //здесь должна быть обработка с учетом всех голосов, это для упрощения
        var rating_common = Math.round((my_voice+rating+2)/2);
        $('.control_rating').html("Оценка:"+rating_common);
        $('.control_your_voice').html("Спасибо, Ваш голос учтен!");
    })

})

function orange_stars(this_elem){
    $.each($('.control_stars_star'), function(i, elem) {
        $(this).css('backgroundPosition', 'bottom');
        if(i > this_elem)
        {
            $(this).css('backgroundPosition', 'top');
        }
    });
}
